import './lib/browser-polyfill.min.js';
import './lib/o200k_base.js';
import { CONFIG, isElectron, RawLog, StoredMap, getStorageValue, setStorageValue, removeStorageValue, sendTabMessage, messageRegistry } from './bg-components/utils.js';
import { tokenStorageManager, tokenCounter } from './bg-components/tokenManagement.js';
import { getStrategy, initContainerStrategy, setBrave } from './bg-components/container-strategy.js';
import { modelFamilyFromVersion, defaultModelForTier, defaultModelVersionForTier } from './shared/dataclasses.js';
// UI strings: the common and tracker tables, then i18n-core.js, which publishes translate() on
// globalThis. The popup and this worker can't see claude.ai's localStorage, so they translate with
// the lastLang the content script stores.
import './common/i18n/all.js';
import './i18n/all.js';
import './common/i18n/i18n-core.js';
import { scheduleAlarm, getAlarm, createNotification } from './bg-components/electron-compat.js';
import { invalidateAccountSettings, invalidateProfileTokens, storeSseUsage, effectiveLeaf } from './bg-components/claude-api.js';

//#region Variable declarations
let processingLock = null;  // Unix timestamp or null
const pendingTasks = [];
const LOCK_TIMEOUT = 30000;  // 30 seconds - if a task takes longer, something's wrong
let pendingRequests;
let scheduledNotifications;
let usageRefreshInFlight = false;

let isInitialized = false;
let functionsPendingUntilInitialization = [];

function runOnceInitialized(fn, args) {
	if (!isInitialized) {
		functionsPendingUntilInitialization.push({ fn, args });
		return;
	}
	return fn(...args);
}
//#endregion

//#region Listener setup (I hate MV3 - listeners must be initialized here)
//Extension-related listeners:
browser.runtime.onMessage.addListener(async (message, sender) => {
	// Log batches and Clear are the shared logger's (common/log/logger.js); letting them through
	// would log "received message" for every batch.
	if (message?.type?.startsWith?.('CLAUDE_EXT_LOG')) return;
	return runOnceInitialized(handleMessageFromContent, [message, sender]);
});




// How the extra usage bar is measured. New installs measure against the monthly spend limit (the
// figure claude.ai itself shows); installs that predate the choice keep measuring against what can
// actually be spent, which was the only behaviour they had. The pref is only written when the
// settings card is saved, so on an update an absent key means "never chose" - pin the legacy value
// then. A fresh install writes the new default explicitly for the same reason: if it relied on the
// read-side default instead, the NEXT release's update would find the key absent, take the install
// for a legacy one and quietly flip it to the old bar.
const EXTRA_USAGE_AGAINST_LIMIT_DEFAULT = true;
browser.runtime.onInstalled?.addListener((details) => {
	if (details.reason !== 'install' && details.reason !== 'update') return;
	getStorageValue('extraUsageAgainstLimit', null).then((stored) => {
		if (stored !== null) return;
		const value = details.reason === 'install' ? EXTRA_USAGE_AGAINST_LIMIT_DEFAULT : false;
		return setStorageValue('extraUsageAgainstLimit', value);
	});
});

if (browser.contextMenus) {
	browser.runtime.onInstalled.addListener(() => {
		browser.contextMenus.create({
			id: 'openDebugPage',
			title: 'Open Debug Page',
			contexts: ['action']
		});

		browser.contextMenus.create({
			id: 'openDonatePage',
			title: 'Donate',
			contexts: ['action']
		});

	});

	browser.contextMenus.onClicked.addListener((info, tab) => {
		if (info.menuItemId === 'openDebugPage') {
			browser.tabs.create({
				url: browser.runtime.getURL('common/log/viewer.html')
			});
		} else if (info.menuItemId === 'openDonatePage') {
			browser.tabs.create({
				url: "https://ko-fi.com/lugia19"
			});
		}
	});
}


if (!isElectron) {
	initContainerStrategy();
}

//Alarm listeners

async function handleAlarm(alarmName) {
	await Log("Alarm triggered:", alarmName);

	if (alarmName === 'checkResetNotifications') {
		// Heartbeat: the only other things that refresh a tab's usage are sending a message and
		// loading a conversation, so a tab left sitting on an expired limit has no way back on its
		// own if its refresh request failed, and usage spent elsewhere (Claude Code, another device)
		// never shows up. Push fresh data every tick regardless of whether reset notifications are
		// enabled. On Electron too: this alarm is the one timer there that outlives the service
		// worker (the launcher holds it in Node), a setInterval doesn't.
		await refreshAllTabsUsage();
		await checkResetNotifications();
	}
}

async function checkResetNotifications() {
	const enabled = await getStorageValue('resetNotifEnabled', false);
	if (!enabled) return;

	const entries = await scheduledNotifications.entries();
	if (!entries || entries.length === 0) return;

	const now = Date.now();
	let shouldNotify = false;

	for (const [timestampKey] of entries) {
		const resetTime = parseInt(timestampKey);
		if (resetTime > now) continue;

		// Skip if reset happened more than 10 minutes ago (stale entry)
		if (now - resetTime > 10 * 60 * 1000) {
			await scheduledNotifications.delete(timestampKey);
			continue;
		}

		// Reset time has passed — check if session usage is at 0%
		try {
			const tabs = await browser.tabs.query({ url: "*://claude.ai/*" });
			if (tabs.length === 0) {
				// No tabs open, remove the entry and skip
				await scheduledNotifications.delete(timestampKey);
				continue;
			}

			const tab = tabs[0];
			const tabOrgId = await requestActiveOrgId(tab);
			const api = getStrategy().apiForTab(tab, tabOrgId);
			const usageData = await api.getUsageData();

			// Only notify if session usage is at 0% (user hasn't started chatting again)
			const sessionLimit = usageData.limits.session;
			if (!sessionLimit || sessionLimit.percentage === 0) {
				shouldNotify = true;
			}
		} catch (error) {
			await Log("warn", "Error checking reset status:", error);
		}

		// Remove processed entry regardless
		await scheduledNotifications.delete(timestampKey);
	}

	if (shouldNotify) {
		try {
			const { lastLang: loc } = await browser.storage.local.get('lastLang');
			await createNotification({
				type: 'basic',
				iconUrl: browser.runtime.getURL('icon128.png'),
				title: translate(loc, 'bg.reset_title'),
				message: translate(loc, 'bg.reset_message')
			});
			await Log("Reset notification sent");
		} catch (error) {
			await Log("error", "Failed to create reset notification:", error);
		}
	}
}
let alarmListenerRegistered = false;
if (chrome.alarms) {
	if (chrome.alarms && !alarmListenerRegistered) {
		alarmListenerRegistered = true;
		chrome.alarms.onAlarm.addListener(alarm => handleAlarm(alarm.name));
	}
} else {
	messageRegistry.register('electron-alarm', (msg) => {
		handleAlarm(msg.name);
	});
}


//#endregion


async function Log(...args) {
	await RawLog("background", ...args)
};

async function logError(error) {
	// If object is not an error, log it as a string
	if (!(error instanceof Error)) {
		await Log("error", JSON.stringify(error));
		return
	}

	await Log("error", error.toString());
	if ("captureStackTrace" in Error) {
		Error.captureStackTrace(error, logError);
	}
	await Log("error", JSON.stringify(error.stack));
}


//#endregion


async function requestActiveOrgId(tab) {
	if (typeof tab === "number") {
		tab = await browser.tabs.get(tab);
	}
	// The active strategy knows how to read the active org for this platform's container model.
	return getStrategy().activeOrgForTab(tab);
}

//#endregion


//#region Messaging

// Updates all tabs with usage data only
async function updateAllTabsWithUsage(usageData = null) {
	await Log("Updating all tabs with usage data");
	const tabs = await browser.tabs.query({ url: "*://claude.ai/*" });

	// Several tabs commonly share one org; fetch once per org rather than once per tab.
	const fetchesByOrg = new Map();

	for (const tab of tabs) {
		// One tab failing (org lookup, fetch, or a tab that closed mid-loop) must not cost every
		// remaining tab its update - this runs unattended from the heartbeat.
		try {
			let data = usageData;

			// If no usageData provided, fetch fresh
			if (!data) {
				const orgId = await requestActiveOrgId(tab);
				if (!fetchesByOrg.has(orgId)) {
					const api = getStrategy().apiForTab(tab, orgId);
					fetchesByOrg.set(orgId, api.getUsageData());
				}
				data = await fetchesByOrg.get(orgId);
			}

			sendTabMessage(tab.id, {
				type: 'updateUsage',
				data: {
					usageData: data.toJSON()
				}
			}).catch(error => Log("warn", `Failed to push usage to tab ${tab.id}:`, error));
		} catch (error) {
			await Log("warn", `Failed to update tab ${tab.id} with usage data:`, error);
		}
	}
}

// A conversation record can lag the message that created it: a freshly created chat comes back from
// the API with no model at all. getInfo() no longer papers over that with a tier default - it
// reports the model as unknown - and isCurrentlyCached refuses to claim a cache hit it cannot
// verify, so without this the indicator would stay hidden on a brand-new chat. The request body we
// captured is authoritative, so prefer it while it is fresh. Bounded by time because pending entries
// now expire rather than being deleted on use.
const PENDING_MODEL_TRUST_MS = 5 * 60 * 1000;

// pendingRequests is two layers: the outer StoredMap key is the conversation, and each value is a
// bucket of { [turn assistant uuid]: entry }.
//
// The inner key comes from turn_message_uuids.assistant_message_uuid in the completion request body
// - claude.ai pre-generates the uuid the assistant message WILL have, and it is the same uuid the
// SSE stream reports as message_start.message.uuid and the tree reports as
// current_leaf_message_uuid. So both the provisional and the authoritative pass can name exactly
// which message they are talking about, instead of "whatever is pending for this conversation".
//
// That ambiguity is what made a second message sent moments after the first read the previous
// message's prompt/model and skip its own accounting. Keeping the conversation as the OUTER
// key preserves StoredMap's per-key TTL at the granularity that matters for eviction, and keeps the
// two consumers that legitimately want "the newest request here" on a single get.
// Marks a bucket key that isn't a real turn uuid — see getPendingRequest.
const SYNTHETIC_TURN_PREFIX = 'ts:';

async function getPendingBucket(orgId, conversationId) {
	const stored = await pendingRequests.get(`${orgId}:${conversationId}`);
	if (!stored || typeof stored !== 'object') return {};

	// Anything that isn't a turn entry is dropped, which is what migrates installs upgrading from
	// the single-entry shape. Those were written with no lifetime, so they never expire on their
	// own, and read as a bucket their FIELDS look like entries — `previousUsage: null` in
	// particular would throw the moment newestPending dereferenced it. They are pre-upgrade and
	// stale regardless, so discarding beats migrating.
	const bucket = {};
	for (const [key, entry] of Object.entries(stored)) {
		if (entry && typeof entry === 'object' && typeof entry.requestTimestamp === 'number') {
			bucket[key] = entry;
		}
	}
	return bucket;
}

// The one entry for a specific generation. Falls back to the newest when the caller has no uuid.
async function getPendingRequest(orgId, conversationId, turnUuid) {
	const bucket = await getPendingBucket(orgId, conversationId);
	if (turnUuid && bucket[turnUuid]) return bucket[turnUuid];
	if (!turnUuid) return newestPending(bucket);

	// Exact miss. Fall back ONLY to entries stored under a synthetic key: those are requests whose
	// body carried no turn_message_uuids, so they can never match the real uuid the callers hold and
	// would otherwise be unreachable — the fallback key would defeat the fallback. A miss against
	// real keys is left as a miss, because borrowing another turn's prompt and model would be worse
	// than reporting none.
	const synthetic = Object.fromEntries(
		Object.entries(bucket).filter(([key]) => key.startsWith(SYNTHETIC_TURN_PREFIX))
	);
	return newestPending(synthetic);
}

function newestPending(bucket) {
	let newest;
	for (const entry of Object.values(bucket)) {
		if (!newest || (entry.requestTimestamp || 0) > (newest.requestTimestamp || 0)) newest = entry;
	}
	return newest;
}

// Writes one generation's entry, dropping siblings that have aged out. No size cap: entries are a
// handful of numbers and short strings, so a burst of regenerations inside the TTL costs bytes.
async function setPendingRequest(orgId, conversationId, turnUuid, entry) {
	// Sweep other conversations' expired buckets while we're writing anyway. Nothing else reads
	// them — a conversation you never revisit is never read, so its bucket would otherwise sit in
	// storage.local for good despite the TTL.
	await pendingRequests.prune();

	const bucket = await getPendingBucket(orgId, conversationId);
	bucket[turnUuid] = entry;

	const cutoff = Date.now() - PENDING_REQUEST_TTL;
	const kept = Object.entries(bucket).filter(([, e]) => (e.requestTimestamp || 0) > cutoff);

	await pendingRequests.set(`${orgId}:${conversationId}`, Object.fromEntries(kept), PENDING_REQUEST_TTL);
}

async function applyPendingModel(conversationData, orgId, conversationId) {
	const pending = newestPending(await getPendingBucket(orgId, conversationId));
	if (!pending || Date.now() - (pending.requestTimestamp || 0) > PENDING_MODEL_TRUST_MS) return;

	if (pending.model) conversationData.model = pending.model;
	if (pending.modelVersion) conversationData.modelVersion = pending.modelVersion;
}

// Updates a specific tab with conversation metrics
async function updateTabWithConversationData(tabId, conversationData) {
	await Log("Updating tab with conversation metrics:", tabId, conversationData);

	sendTabMessage(tabId, {
		type: 'updateConversationData',
		data: {
			conversationData: conversationData.toJSON()
		}
	});
}

// Create the registry

// Simple handlers with inline functions
messageRegistry.register('getConfig', () => CONFIG);
messageRegistry.register('initOrg', (message, sender, orgId) => tokenStorageManager.addOrgId(orgId).then(() => true));

messageRegistry.register('getAPIKey', () => getStorageValue('apiKey'));
messageRegistry.register('setAPIKey', async (message) => {
	const newKey = message.newKey;
	if (newKey === "") {
		await removeStorageValue('apiKey');
		return true;
	}

	// Test the new key
	const isValid = await tokenCounter.testApiKey(newKey);

	if (isValid) {
		await setStorageValue('apiKey', newKey);
		await Log("API key validated and saved");
		return true;
	} else {
		await Log("warn", "API key validation failed");
		return false;
	}
});

messageRegistry.register('getResetNotifEnabled', () => getStorageValue('resetNotifEnabled', false));
messageRegistry.register('setResetNotifEnabled', (message) => setStorageValue('resetNotifEnabled', message.value));

messageRegistry.register('getResetNotifThreshold', () => getStorageValue('resetNotifThreshold', 100));
messageRegistry.register('setResetNotifThreshold', (message) => {
	const n = Number(message.value);
	const clamped = Number.isFinite(n) ? Math.min(100, Math.max(1, Math.round(n))) : 100;
	return setStorageValue('resetNotifThreshold', clamped);
});


messageRegistry.register('getExtraUsageAgainstLimit', () => getStorageValue('extraUsageAgainstLimit', EXTRA_USAGE_AGAINST_LIMIT_DEFAULT));
messageRegistry.register('setExtraUsageAgainstLimit', (message) => setStorageValue('extraUsageAgainstLimit', message.value === true));

messageRegistry.register('isElectron', () => isElectron);

// The content script reports whether we're on Brave (navigator.brave.isBrave()). On Brave we can't
// read per-container cookies, so claude.ai fetches are proxied through the originating tab instead.
messageRegistry.register('reportBrave', async (message) => {
	await setBrave(message.isBrave);
	return true;
});

// Complex handlers
async function requestData(message, sender, orgId) {
	const { conversationId } = message;
	if (!orgId) return; // no org cookie: nothing to fetch for

	const api = getStrategy().apiForTab(sender.tab, orgId);

	// Always fetch and send fresh usage data
	const usageData = await api.getUsageData();
	await scheduleResetNotifications(orgId, usageData);
	await updateAllTabsWithUsage(usageData);

	if (conversationId) {
		// Check conversation cache
		const cached = await conversationCache.get(conversationId);
		if (cached) {
			await Log(`Cache hit for conversation: ${conversationId}`);

			// Swap to uncached costs if prompt cache has expired
			if (cached.conversationIsCachedUntil && cached.conversationIsCachedUntil <= Date.now()) {
				cached.cost = cached.uncachedCost;
				cached.futureCost = cached.uncachedFutureCost;
				cached.conversationIsCachedUntil = null;
			}

			await sendTabMessage(sender.tab.id, {
				type: 'updateConversationData',
				data: { conversationData: cached }
			});
		} else {
			await Log(`Cache miss for conversation: ${conversationId}`);
			const conversation = await api.getConversation(conversationId);
			const conversationData = await conversation.getInfo(false);

			if (conversationData) {
				// Before caching, so the correction sticks for the cache's lifetime too.
				await applyPendingModel(conversationData, orgId, conversationId);

				await conversationCache.set(conversationId, conversationData.toJSON(), CONVERSATION_CACHE_TTL);
				await updateTabWithConversationData(sender.tab.id, conversationData);
			}
		}
	}

	await Log("Sent update messages to tab");
	return true;
}
messageRegistry.register(requestData);

// A provisional conversation update, built from the completion stream rather than the network, so
// the length/cost/cached figures move the moment generation ends instead of ~1-2s later. Reported
// by content-components/sse_bridge.js, which counts the reply's tokens in-page.
//
// HARD CONSTRAINT: this handler makes no network calls. Everything it needs is already in
// pendingRequests (written when the POST went out) and conversationCache (written by the last
// authoritative pass). A single fetch here would put it back in the latency it exists to avoid.
//
// It also skips every side effect the authoritative pass has - no scheduleResetNotifications, no
// addToTotalTokens, no debugLogMessageCost. An estimate must never fire a notification or land in
// the lifetime token counter.
async function reportStreamCompletion(message, sender, orgId) {
	if (!orgId || !sender?.tab) return false;

	// Persisted before the estimate's own preconditions, because the two payloads are independent:
	// on the free plan /usage reports nothing, so this snapshot is the only usage that will ever
	// exist for the account, and it must not be lost to a conversation the estimate can't price.
	//
	// Ordering note: the authoritative pass fetches usage ~0.2s later (its trigger is claude.ai's
	// post-message tree GET, or on the merged experience the StreamTimeline settle, which follows the
	// stream's message_limit), so this write lands first and that fetch picks it up. If it ever lost
	// that race the bars would simply wait for the next message, which is what the free-plan hint
	// tells the user to do anyway.
	await storeSseUsage(getStrategy().apiForTab(sender.tab, orgId), message.sseLimits);

	const conversationId = message.conversationId;
	if (!conversationId || message.assistantTokens === null) return false;

	// Indexed by the assistant uuid the stream just reported, so this reads THIS generation's
	// prompt/model even if the next message went out while the previous pass was still
	// running. Without the uuid (shouldn't happen - message_start always carries it) fall back to
	// the newest entry, which is the pre-uuid behaviour.
	const pending = await getPendingRequest(orgId, conversationId, message.assistantUuid);
	const cached = await conversationCache.get(conversationId);
	// No baseline, no estimate. Synthesizing one from the fixed system prompt would miss profile
	// tokens, files and project knowledge - a brand-new conversation is better off waiting the
	// second for the real numbers.
	if (!pending || !cached) {
		await Log("Stream completion: no baseline for", conversationId, "- skipping estimate");
		return false;
	}

	// Copy first: StoredMap.get hands back the live in-memory object, so mutating it in place
	// would quietly corrupt the cached entry for every later reader.
	const provisional = { ...cached };

	const assistantTokens = Math.max(0, message.assistantTokens || 0);
	// A regeneration has no new human message; its body carries no prompt, so this is already 0,
	// but be explicit rather than relying on that.
	const promptTokens = pending.isRetry ? 0 : Math.max(0, pending.promptTokens || 0);

	// A regeneration replaces the previous reply rather than appending to it, so adding both would
	// double-count. We don't know the replaced message's size, so hold the length and let the
	// estimate asterisk say so.
	const appendOk = !pending.isRetry;
	if (appendOk) {
		provisional.length = (cached.length || 0) + promptTokens + assistantTokens;
	}

	// futureCost is NOT a running total, and this is the easiest thing in the file to get wrong.
	// getInfo adds every message on the trunk (claude-api.js:707) and then subtracts the entire
	// cached prefix straight back out (:715, since 1 - CACHING_MULTIPLIER is 1), so once a reply
	// lands the only survivor is that reply. Hence assign, never +=. Adding to the previous value
	// would carry the last turn's reply forward and roughly double the displayed cost each message.
	provisional.futureCost = Math.round((1 + CONFIG.OUTPUT_TOKEN_MULTIPLIER) * assistantTokens);
	provisional.cost = provisional.futureCost;

	// uncachedCost genuinely IS cumulative - it never subtracts a cached prefix - so it keeps
	// accumulating. It only surfaces while the conversation reads as uncached, which never happens
	// immediately after a reply, so its drift stays invisible until the real pass corrects it.
	provisional.uncachedFutureCost = (cached.uncachedFutureCost || 0) + promptTokens + assistantTokens;
	provisional.uncachedCost = provisional.uncachedFutureCost;

	// The reply just created an anchor at the end of the new human message, so the conversation is
	// cached from now, whatever it was before.
	provisional.conversationIsCachedUntil = Date.now() + CONFIG.TOKEN_CACHING_DURATION_MS;
	provisional.costUsedCache = true;
	provisional.lastMessageTimestamp = Date.now();
	// Names the turn this estimate describes, so the authoritative pass that follows recognises it
	// as the same message rather than a new one - see ConversationData.lastMessageUuid. Straight
	// from the stream, which reports the uuid the tree will come back with. A synthetic key is a
	// timestamp wearing a uuid's clothes and would compare unequal to the real one anyway, so it is
	// dropped rather than passed off as an identity.
	provisional.lastMessageUuid = message.assistantUuid ||
		(pending.turnUuid && !pending.turnUuid.startsWith(SYNTHETIC_TURN_PREFIX) ? pending.turnUuid : null);
	// isCurrentlyCached() compares modelVersion against the picker, so a stale one hides the cache
	// indicator. pendingRequests took this from the request body, which is authoritative.
	provisional.model = pending.model || provisional.model;
	provisional.modelVersion = pending.modelVersion || provisional.modelVersion;
	provisional.orgId = orgId;
	provisional.conversationId = conversationId;
	provisional.lengthIsEstimate = !!(cached.lengthIsEstimate || message.unreliable ||
		pending.hasAttachments || !appendOk);

	// Short TTL, unlike the authoritative 60 minutes: if the real pass never lands, requestData
	// would otherwise serve this estimate as fact for the rest of the hour.
	await conversationCache.set(conversationId, provisional, PROVISIONAL_CACHE_TTL);

	await Log("Stream completion: provisional length", provisional.length,
		"futureCost", provisional.futureCost, "(assistant", assistantTokens,
		"prompt", promptTokens, ")");

	await sendTabMessage(sender.tab.id, {
		type: 'updateConversationData',
		data: { conversationData: provisional }
	});

	// Deliberately does NOT kick off the authoritative pass. That was tried, and the 200ms of head
	// start it bought (claude.ai refetches the tree ~0.2s after the stream ends) was invisible —
	// the provisional above already landed at ~50ms with values that converge exactly. What it cost
	// was a second trigger source for the same message, and with it a stale-tree retry, a dedupe
	// window, an in-flight/deferral dance, and two bugs. onCompletedHandler's tree GET is the
	// trigger, and its completing is proof the tree exists. (Merged-experience accounts make no such
	// GET and no completion stream; their trigger is onTurnSettled.)
	return true;
}
messageRegistry.register(reportStreamCompletion);

// Serialises the authoritative pass onto the existing task queue, dropping a trigger that overlaps
// one already in flight for the same message.
//
// Tree-GET triggers don't say which message they're about, so they collapse per conversation, which
// is safe: overlapping tree GETs are always about the same message (claude.ai's own refetch and
// Claude QoL's TTS interceptor arrive ~0.1s apart; the next message's GET can't come until a whole
// generation later). Stream settles do name their turn, and their pass can wait ~2s for the tree to
// catch up, long enough for a fast next turn to settle; so they collapse per conversation AND turn,
// and a different turn queues instead of being dropped. The flag is cleared in a finally, so nothing
// stays suppressed.
function queueAuthoritativePass(options) {
	const key = options.expectedTurn ? `${options.conversationId}:${options.expectedTurn}` : options.conversationId;
	if (authoritativeInFlight.has(key)) return;
	authoritativeInFlight.add(key);
	pendingTasks.push(async () => {
		try {
			await runAuthoritativePass(options);
		} catch (error) {
			await logError(error);
		} finally {
			authoritativeInFlight.delete(key);
		}
	});
	processNextTask();
}

// Both triggers' common half: queue the pass for the tab the trigger came from. extra carries the
// stream trigger's expectedTurn.
function triggerAuthoritativePass(details, orgId, conversationId, extra = {}) {
	queueAuthoritativePass({
		orgId,
		conversationId,
		api: getStrategy().apiForRequest(details, orgId),
		tabId: details.tabId,
		...extra,
	});
	tokenStorageManager.addOrgId(orgId);
}

async function getPopupUsageData() {
	// The active strategy owns discovery: it returns [{ orgId, ctx }] for this platform's container model.
	const accounts = await getStrategy().listAccounts();
	if (accounts.length === 0) return [];

	// Each account resolves to a success or a structured error (never rejects), so error entries keep
	// their orgId and a cached name for the popup to render as an "unavailable" row.
	return Promise.all(accounts.map(async ({ orgId, ctx }) => {
		const api = getStrategy().apiFor(ctx, orgId);
		try {
			const usageData = await api.getUsageData();
			const org = await api.getOrgInfo(); // cache hit — getUsageData already fetched it
			return { orgId, orgName: org?.name || null, usageData: usageData.toJSON() };
		} catch (e) {
			const org = await api.getOrgInfo().catch(() => null); // cached name if available
			return { orgId, orgName: org?.name || null, error: String(e) };
		}
	}));
}
messageRegistry.register(getPopupUsageData);

// The page's requests, from injections/request-hook.js via content-components/request_relay.js. The
// tab (and its container) come from the sender, which is all apiForRequest needs.
const fromTab = (handler) => (message, sender) => {
	handler({ ...message.details, tabId: sender.tab.id, cookieStoreId: sender.tab.cookieStoreId });
	return true;
};
messageRegistry.register('interceptedRequest', fromTab(onBeforeRequestHandler));
messageRegistry.register('interceptedResponse', fromTab(onCompletedHandler));
messageRegistry.register('turnSettled', fromTab(onTurnSettled));

async function getTotalTokensTracked() {
	return await tokenStorageManager.getTotalTokens();
}
messageRegistry.register(getTotalTokensTracked);

// Main handler function
async function handleMessageFromContent(message, sender) {
	return messageRegistry.handle(message, sender);
}
//#endregion



//#region Network handling
// The authoritative pass. One per sent message, triggered by claude.ai's post-message tree GET
// (onCompletedHandler), or on merged-experience accounts, which make no such GET, by the turn
// settling on its StreamTimeline (onTurnSettled), which passes `expectedTurn`: the reply the tree
// should end on (null if not even a pending send names one).
//
// `api` is passed in rather than derived because the caller is a request handler and has to
// build it from `details` (the tab the request came from) via the active container strategy.
//
// `sessionId`: on a workspace-upgraded chat, the settle also names the chat's Claude Code session,
// and getInfo reads the real context size from it (once per settled turn: see getContextUsage).
async function runAuthoritativePass({ orgId, conversationId, api, tabId, expectedTurn, sessionId }) {
	await Log("Running authoritative pass for", conversationId, expectedTurn !== undefined ? `(stream settle, turn ${expectedTurn})` : '');

	// Fetch current usage limits from endpoint, and send them out before getInfo, which can wait on a
	// Claude Code session for a few seconds.
	const usageData = await api.getUsageData();
	await scheduleResetNotifications(orgId, usageData);
	await updateAllTabsWithUsage(usageData);

	// Fetch conversation data
	const conversation = await api.getConversation(conversationId);

	// Which generation this pass is about. When the tree GET triggered us, it has already completed,
	// so the tree is guaranteed to contain the new reply and its leaf IS that reply — no staleness
	// check needed, which is the main reason legacy accounts trigger from the tree GET rather than
	// from the completion stream. The merged experience makes no such GET, so there the trigger is
	// the StreamTimeline settle (onTurnSettled), and getSettledTree makes up for the missing proof.
	// The tree is memoized per shape, so getInfo below reuses this read.
	const tree = expectedTurn === undefined ? await conversation.getData(true) : await conversation.getSettledTree(expectedTurn);
	// Always the tree's own leaf. expectedTurn only steers the freshness wait: if the tree never
	// caught up (or a fast next turn already moved the leaf on), pricing it as expectedTurn would pair
	// that turn's pending entry with another generation's data and settle it for good. Keyed on the
	// leaf, a stale tree finds no pending entry (a display refresh), and a newer leaf is priced as
	// itself (its own settle then repeats harmlessly).
	//
	// Accepted by design: in that last case (turn B settled before turn A's pass read the tree, a
	// ~1-2s window), A's one-shot side effects (its usage-delta log line and its cost in the lifetime
	// token counter) are skipped. The displayed numbers stay right, B's pass prices the whole
	// conversation; recovering A's share would mean pricing a tree truncated at A, for one statistic.
	//
	// "Leaf" skips a compaction divider, which lands on top of the turn's reply.
	const turnUuid = effectiveLeaf(tree);

	// Scoped to this generation rather than "whatever is pending for this conversation", so a
	// message sent while a previous pass was still running can't have its data read here.
	const pendingRequest = await getPendingRequest(orgId, conversationId, turnUuid);
	const isNewMessage = pendingRequest !== undefined;
	// The entry is no longer deleted after the first pass — deleting it is what made the second run
	// disagree with the first, dropping the request's model and changing the displayed cost. It is
	// marked instead, so a repeat pass over the same message still prices it identically while the
	// one-shot side effects (lifetime token counter, usage delta log) fire exactly once.
	const alreadyCounted = !!pendingRequest?.settled;

	const conversationData = await conversation.getInfo(isNewMessage, sessionId);

	if (!conversationData) {
		await Log("warn", "Could not get conversation data, exiting...");
		return false;
	}

	// Both model fields are overridden only when the request that triggered this pass actually knows
	// better. getInfo already derives them from the conversation's own `model`, and the pass also
	// runs on plain navigation, where there is no pendingRequest at all - assigning the tier default
	// unconditionally there replaced a correct family (Fable) with a wrong one (Opus), leaving
	// `model` and `modelVersion` describing different models.
	await Log('authoritative pass: model -',
		'from API:', conversationData.model, conversationData.modelVersion,
		'| from pendingRequest:', pendingRequest?.model, pendingRequest?.modelVersion);
	if (pendingRequest?.model) {
		conversationData.model = pendingRequest.model;
	}
	if (pendingRequest?.modelVersion) {
		conversationData.modelVersion = pendingRequest.modelVersion;
	}
	await Log('authoritative pass: model final:', conversationData.model, conversationData.modelVersion);

	// If new message: update total tokens. Once per message, never on a repeat pass.
	if (isNewMessage && !alreadyCounted) {
		// Add message cost to total tracked
		await tokenStorageManager.addToTotalTokens(conversationData.cost);

		// Debug: log per-message cost keyed by limit reset timestamps
		await debugLogMessageCost(usageData, conversationData);
	}

	// Marks THIS generation settled and nothing else. The previous version wrote the whole
	// conversation's entry back from a snapshot taken at the top of the pass, so a message sent
	// during the pass had its freshly-stored data reverted and pre-marked settled — losing its
	// prompt/model and skipping its own accounting.
	if (isNewMessage && !alreadyCounted && pendingRequest.turnUuid) {
		await setPendingRequest(orgId, conversationId, pendingRequest.turnUuid,
			{ ...pendingRequest, settled: true });
	}

	await updateTabWithConversationData(tabId, conversationData);

	await conversationCache.set(conversationId, conversationData.toJSON(), CONVERSATION_CACHE_TTL);

	return true;
}

async function debugLogMessageCost(usageData, conversationData) {
	const limitMapping = {
		session: 'debug_session',
		weekly: 'debug_weekly',
		sonnetWeekly: 'debug_sonnet_weekly',
		opusWeekly: 'debug_opus_weekly',
		fableWeekly: 'debug_fable_weekly'
	};

	for (const [limitKey, storagePrefix] of Object.entries(limitMapping)) {
		const limit = usageData.limits[limitKey];
		if (!limit) continue;

		const storageKey = `${storagePrefix}_${limit.resetsAt}`;
		const existing = await getStorageValue(storageKey, {
			resetsAt: limit.resetsAt,
			limitKey,
			messages: [],
			accumulatedCost: 0,
			lastPercentage: null
		});

		const percentageChanged = existing.lastPercentage !== null && limit.percentage !== existing.lastPercentage;

		if (percentageChanged) {
			// Percentage changed - log entry with accumulated cost included
			const entry = {
				timestamp: Date.now(),
				cost: conversationData.cost,
				accumulatedCost: existing.accumulatedCost,
				totalCost: conversationData.cost + existing.accumulatedCost,
				futureCost: conversationData.futureCost,
				model: conversationData.model,
				conversationLength: conversationData.length,
				percentageDelta: limit.percentage - existing.lastPercentage,
			};
			existing.messages.push(entry);
			existing.accumulatedCost = 0; // Reset accumulator
			await Log(`Debug [${limitKey}]: logged message cost ${entry.totalCost} (accumulated: ${entry.accumulatedCost}, this msg: ${entry.cost}, delta: ${entry.percentageDelta}%)`);
		} else {
			// Percentage didn't change - accumulate the cost
			existing.accumulatedCost += conversationData.cost;
			await Log(`Debug [${limitKey}]: accumulated cost ${conversationData.cost}, total accumulated: ${existing.accumulatedCost}`);
		}

		existing.lastPercentage = limit.percentage;
		await setStorageValue(storageKey, existing);
	}
}


async function scheduleResetNotifications(orgId, usageData) {
	const threshold = await getStorageValue('resetNotifThreshold', 100);
	const maxedLimits = usageData.getMaxedLimits(threshold);

	for (const limit of maxedLimits) {
		// Skip limits whose reset time has already passed
		if (limit.resetsAt <= Date.now()) continue;

		const timestampKey = limit.resetsAt.toString();

		if (await scheduledNotifications.has(timestampKey)) continue;

		const expiryTime = limit.resetsAt + (60 * 60 * 1000) - Date.now();
		await scheduledNotifications.set(timestampKey, orgId, expiryTime);

		await Log(`Stored pending reset: ${limit.key} for ${new Date(limit.resetsAt).toISOString()}`);
	}
}


// Listen for message sending
async function onBeforeRequestHandler(details) {
	await Log("Intercepted request:", details.url);
	// A message send, from /completion or a merged-experience PerformAction: request-hook.js reports
	// both as kind 'send' with the ids, isRetry, inheritsModel and the /completion body's fields.
	if (details.kind === "send") {
		await Log("Request sent - URL:", details.url);
		const requestBodyJSON = details.requestBody; // parsed by the hook
		// Shape only, never the prompt or attachment text: the debug log is persisted and viewable.
		await Log("Request sent - Body:", {
			model: requestBodyJSON?.model,
			parent_message_uuid: requestBodyJSON?.parent_message_uuid,
			turn_message_uuids: requestBodyJSON?.turn_message_uuids,
			promptChars: requestBodyJSON?.prompt?.length ?? 0,
			attachments: requestBodyJSON?.attachments?.length ?? 0,
			files: requestBodyJSON?.files?.length ?? 0,
			tools: requestBodyJSON?.tools?.length ?? 0,
		});
		const conversationId = details.conversationId;
		if (!conversationId) {
			await Log("warn", "Message send without a conversation id, not recorded:", details.url);
			return;
		}
		const orgId = details.orgId || await requestActiveOrgId(details.tabId);
		await tokenStorageManager.addOrgId(orgId);

		// Nothing slow is awaited before the pending entry is stored: on the merged experience a short
		// or failed turn can settle within a second, and its pass must find the entry. The one lookup
		// left, the subscription tier, is only for a legacy send that names no model, and is cached.
		let subscriptionTier = null;
		if (!requestBodyJSON?.model && !details.inheritsModel) {
			try {
				subscriptionTier = await getStrategy().apiForRequest(details, orgId).getSubscriptionTier();
			} catch (error) {
				await Log("warn", "Failed to read the subscription tier for the default model:", error);
			}
		}

		// No model in the body: a legacy send means the tier's default; a send that inheritsModel (merged,
		// which names it only on a conversation's first message) keeps the conversation's own, so record
		// none rather than a default that would overwrite it.
		const modelVersion = requestBodyJSON?.model || (details.inheritsModel ? null : defaultModelVersionForTier(subscriptionTier));
		const model = modelVersion && (modelFamilyFromVersion(modelVersion) || defaultModelForTier(subscriptionTier));
		await Log("Model from request:", model, modelVersion);

		// The uuid this generation's assistant message will have, declared by the client before the
		// message exists. Present on /completion and /retry_completion alike (a regeneration gets a
		// fresh one, so retries key distinctly rather than colliding). Verified against the tree:
		// it comes back as current_leaf_message_uuid, and the SSE stream reports the same value.
		// The timestamp fallback keeps the bucket usable if the field ever disappears - exact
		// matching degrades to newest-wins, which is the old behaviour.
		let turnUuid = requestBodyJSON?.turn_message_uuids?.assistant_message_uuid;
		if (!turnUuid) {
			// Loud, because the degradation is otherwise invisible: every request would get a unique
			// key, every exact lookup would miss, and we would silently fall back to newest-wins —
			// which is the behaviour the per-turn keying exists to replace.
			await Log("warn", "No turn_message_uuids.assistant_message_uuid in the completion body —",
				"per-turn keying is degraded to newest-wins for this request");
			turnUuid = `${SYNTHETIC_TURN_PREFIX}${Date.now()}`;
		}
		await Log(`Message sent - conversation ${conversationId}, turn ${turnUuid}`);

		// Size of the outgoing message, for the provisional estimate in reportStreamCompletion.
		// This is the only place the prompt is visible - by the time the stream ends it is gone.
		// Deliberately a COUNT and not the text: pendingRequests is a StoredMap, so anything put
		// here is written to storage.local, and PRIVACY.md promises message content never is.
		// Counted locally rather than via countText so no request body is shipped to the
		// token-count API just to feed a display estimate.
		let promptTokens = 0;
		let hasAttachments = false;
		try {
			promptTokens = tokenCounter.countTextLocal(requestBodyJSON?.prompt || '');
			// Attachments and files are real tokens the estimate can't see, so they only mark the
			// result as an estimate rather than being counted.
			hasAttachments = !!(requestBodyJSON?.attachments?.length || requestBodyJSON?.files?.length);
		} catch (error) {
			await Log("warn", "Failed to size outgoing message:", error);
		}

		// Store pending request with all data
		await Log('onBeforeRequest: storing modelVersion:', modelVersion, '| class:', model);
		await setPendingRequest(orgId, conversationId, turnUuid, {
			orgId: orgId,
			conversationId: conversationId,
			turnUuid: turnUuid,
			tabId: details.tabId,
			model: model,
			modelVersion: modelVersion,
			requestTimestamp: Date.now(),
			promptTokens: promptTokens,
			hasAttachments: hasAttachments,
			isRetry: details.isRetry
		});
	}

	if (details.method === "PUT" && details.url.includes("/account_profile")) {
		// This same request carries edited conversation preferences, which are priced into every
		// conversation, so drop the cached token count rather than waiting out its TTL.
		await invalidateProfileTokens(await requestActiveOrgId(details.tabId));
	}

	// The user toggled a feature (memory, web search, ...). Drop the cached account settings
	// so the next cost computation reflects it instead of waiting out the TTL. Matching every
	// write verb rather than just one - the UI currently uses PATCH, but that's not contractual.
	if (["POST", "PATCH", "PUT"].includes(details.method) && details.url.includes("/account/settings")) {
		const orgId = await requestActiveOrgId(details.tabId);
		await invalidateAccountSettings(orgId);
	}

	if (details.method === "GET" && details.url.includes("/settings/billing")) {
		await Log("Hit the billing page, let's make sure we get the updated subscription tier in case it was changed...")
		const orgId = await requestActiveOrgId(details.tabId);
		const api = getStrategy().apiForRequest(details, orgId);
		await api.getSubscriptionTier(true);
	}

}

// A merged-experience turn ended (request-hook.js watches the page's StreamTimeline): the merged
// experience's stand-in for the post-message tree GET below. assistantMessageId is the turn's key in
// pendingRequests (recorded from its PerformAction send). It can be missing when the turn straddled a
// stream reconnect; then the newest turn sent here and not yet priced stands in, so the pass still
// waits for the tree to show it rather than pricing whatever leaf the first read has.
async function onTurnSettled(details) {
	const { orgId, conversationId, assistantMessageId, stopReason, sessionId } = details;
	if (!orgId || !conversationId) return;
	let expectedTurn = assistantMessageId || null;
	if (!expectedTurn) {
		const unsettled = Object.values(await getPendingBucket(orgId, conversationId)).filter(e => !e.settled);
		expectedTurn = newestPending(Object.fromEntries(unsettled.map(e => [e.turnUuid, e])))?.turnUuid ?? null;
	}
	await Log("Turn settled:", conversationId, assistantMessageId ?? `(no id; newest unsettled send: ${expectedTurn})`, stopReason, sessionId ?? '');
	triggerAuthoritativePass(details, orgId, conversationId, { expectedTurn, sessionId: typeof sessionId === 'string' ? sessionId : null });
}

async function onCompletedHandler(details) {
	if (details.method === "GET" &&
		details.url.includes("/chat_conversations/") &&
		details.url.includes("tree=True") &&
		details.url.includes("render_all_tools=true")) {

		const urlParts = details.url.split('/');
		const conversationId = urlParts[urlParts.indexOf('chat_conversations') + 1]?.split('?')[0];

		// The legacy trigger for the authoritative pass (merged-experience accounts never make this
		// GET; their trigger is onTurnSettled, from the StreamTimeline). claude.ai refetches the tree
		// ~0.2s after a completion stream ends, and that GET completing is proof the new reply is in the tree —
		// which is why triggering here needs no staleness check.
		//
		// Measured with every extension disabled: claude.ai issues exactly ONE of these per message
		// (plus one on page load, distinguishable by consistency=strong vs eventual). A second one
		// used to show up and get blamed on claude.ai; it is actually Claude QoL's TTS interceptor
		// (Claude-Toolbox content/main/tts-interceptor.js), which fetches the same URL shape. It
		// lands ~0.1s after claude.ai's, so the in-flight check below collapses the two.
		//
		// Deliberately matched broadly rather than on consistency=eventual: filtering on an
		// undocumented query param would silently kill the only trigger if claude.ai dropped it.
		if (authoritativeInFlight.has(conversationId)) {
			Log("Tree GET for", conversationId, "— a pass is already in flight, skipping");
			return;
		}

		triggerAuthoritativePass(details, urlParts[urlParts.indexOf('organizations') + 1], conversationId);
	}

	// Branch switch — debounce, then invalidate cache and fetch fresh data
	if (details.url.includes("/current_leaf_message_uuid")) {
		const urlParts = details.url.split('/');
		const conversationId = urlParts[urlParts.indexOf('chat_conversations') + 1];

		if (branchSwitchTimers.has(conversationId)) {
			clearTimeout(branchSwitchTimers.get(conversationId));
		}

		branchSwitchTimers.set(conversationId, setTimeout(() => {
			branchSwitchTimers.delete(conversationId);
			pendingTasks.push(async () => {
				const orgId = urlParts[urlParts.indexOf('organizations') + 1];

				await conversationCache.delete(conversationId);
				await Log("Branch switch detected — fetching fresh data for:", conversationId);

				const api = getStrategy().apiForRequest(details, orgId);
				const conversation = await api.getConversation(conversationId);
				const conversationData = await conversation.getInfo(false);

				if (conversationData) {
					await conversationCache.set(conversationId, conversationData.toJSON(), CONVERSATION_CACHE_TTL);
					await updateTabWithConversationData(details.tabId, conversationData);
				}
			});
			processNextTask();
		}, 5000));
	}

	// A message sent to a claude.ai/code session (the page's GETs of the event log don't count) —
	// refresh usage. Only the send is visible: the session runs remotely, so what it spends shows up
	// on the next refresh (this, a later send, or the heartbeat).
	if (details.method === "POST" && /\/v1\/code\/sessions\/[^/]+\/events$/.test(details.url.split('?', 1)[0])) {
		pendingTasks.push(async () => {
			const orgId = await requestActiveOrgId(details.tabId);
			if (!orgId) return;
			await tokenStorageManager.addOrgId(orgId);
			const api = getStrategy().apiForRequest(details, orgId);
			const usageData = await api.getUsageData();
			await updateAllTabsWithUsage(usageData);
			await scheduleResetNotifications(orgId, usageData);
		});
		processNextTask();
	}
}

async function processNextTask() {
	// Check if already processing
	if (processingLock) {
		const lockAge = Date.now() - processingLock;
		if (lockAge < LOCK_TIMEOUT) {
			return;  // Still legitimately processing
		}
		// Lock is stale, force clear it
		await Log("warn", `Stale processing lock detected (${lockAge}ms old), clearing`);
	}

	if (pendingTasks.length === 0) return;

	processingLock = Date.now();
	const task = pendingTasks.shift();

	try {
		await task();
	} catch (error) {
		await Log("error", "Task processing failed:", error);
	} finally {
		// ALWAYS clear the lock, no matter what
		processingLock = null;

		// Process next task if any
		if (pendingTasks.length > 0) {
			processNextTask();  // Not awaited
		}
	}
}
//#endregion

// Fresh usage for every tab, for the triggers that aren't a request: the heartbeat, and the Electron
// window regaining focus. One at a time; a trigger arriving while one runs is dropped.
async function refreshAllTabsUsage() {
	if (usageRefreshInFlight) return;
	usageRefreshInFlight = true;
	try {
		await updateAllTabsWithUsage();
	} catch (error) {
		await Log("warn", "Usage refresh failed:", error);
	} finally {
		usageRefreshInFlight = false;
	}
}

//#region Variable fill in and initialization
pendingRequests = new StoredMap("pendingRequests"); // conversationId -> {userId, tabId}
scheduledNotifications = new StoredMap('scheduledNotifications');
const conversationCache = new StoredMap("conversationCache");	// This is for convo stats
const CONVERSATION_CACHE_TTL = 60 * 60 * 1000; // 60 minutes
// Provisional entries written by reportStreamCompletion expire far sooner than real ones. The
// authoritative pass normally overwrites them within a second or two; this only bounds how long a
// stream-derived estimate can be served as fact if that pass never arrives.
const PROVISIONAL_CACHE_TTL = 2 * 60 * 1000; // 2 minutes
const branchSwitchTimers = new Map(); // conversationId → timeoutId (debounce)

// Conversations with a pass queued or running. Overlapping tree GETs are always about the same
// message, so a second trigger arriving while one is in flight is a duplicate and gets dropped.
const authoritativeInFlight = new Set();

// pendingRequests entries expire rather than being deleted by the pass that consumes them: long
// enough that a repeat pass for the same message still sees the model it was sent with, short
// enough that revisiting the conversation later isn't read as a fresh send.
const PENDING_REQUEST_TTL = 10 * 60 * 1000;

// Set up repeating alarm for reset notification polling (every 3 minutes)
const HEARTBEAT_ALARM = { periodInMinutes: 3 };
getAlarm('checkResetNotifications').then(existing => {
	if (!existing) {
		scheduleAlarm('checkResetNotifications', HEARTBEAT_ALARM);
		Log("Created repeating checkResetNotifications alarm");
	}
});

isInitialized = true;
for (const handler of functionsPendingUntilInitialization) {
	handler.fn(...handler.args);
}
functionsPendingUntilInitialization = [];
Log("Done initializing.")

if (isElectron) {
	// The launcher dispatches this when the window gains focus: the likeliest moment for usage spent
	// elsewhere (the desktop app's Code tab runs the CLI, which the page never sees) to be looked at.
	// It also re-sends the heartbeat alarm. The create sent at app launch can reach the page before the
	// launcher hooks its console, and is then lost for good: nothing else wakes the worker to send it
	// again. This event comes from that hook, so it can't be early, and the launcher ignores a repeat.
	messageRegistry.register('electronTabActivated', () => {
		scheduleAlarm('checkResetNotifications', HEARTBEAT_ALARM);
		refreshAllTabsUsage();
		return true;
	});
}
//#endregion