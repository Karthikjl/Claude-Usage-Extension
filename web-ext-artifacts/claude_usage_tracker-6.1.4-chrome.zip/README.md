# Claude Usage Tracker Extension

Track your Claude.ai token usage across conversations with this browser extension.

Also check out my other extension, [[Claude QoL](https://github.com/lugia19/Claude-QoL)] (includes summarizing, TTS, STT and way more).

## Overview

This extension helps you monitor how much of your Claude usage quota remains. It calculates token consumption from various sources including uploaded files, project knowledge, chat history, and AI responses.

## Installation

### Direct Download (Pre-built ZIP)

Download the latest built extension package directly:
- 📦 **[Download Latest Chrome/Brave/Edge Extension (.zip)](./web-ext-artifacts/claude_usage_tracker-6.1.4-chrome.zip)**

**How to install in Chrome / Brave / Edge:**
1. Download and extract [`claude_usage_tracker-6.1.4-chrome.zip`](./web-ext-artifacts/claude_usage_tracker-6.1.4-chrome.zip).
2. Go to `chrome://extensions` (or `brave://extensions` / `edge://extensions`).
3. Enable **Developer mode** (toggle in the top-right corner).
4. Click **Load unpacked** and select the extracted folder.

### Chrome Web Store
[![Chrome Web Store](https://img.shields.io/chrome-web-store/v/knemcdpkggnbhpoaaagmjiigenifejfo.svg)](https://chrome.google.com/webstore/detail/claude-usage-tracker/knemcdpkggnbhpoaaagmjiigenifejfo)

### Firefox
[![Mozilla Add-on](https://img.shields.io/amo/v/claude-usage-tracker.svg)](https://addons.mozilla.org/firefox/addon/claude-usage-tracker)

### Desktop Client

[MacOS/Windows installer](https://github.com/lugia19/Claude-WebExtension-Launcher/releases/latest)

## Features

The extension tracks token usage from:

- **Files** - Documents uploaded to chats
- **Projects** - Knowledge files and custom instructions
- **Personal preferences** - Your configured settings
- **Message history** - Full conversation context, including the results of tools Claude ran (they stay in context for later messages)
- **System prompts** - Enabled tools (analysis, artifacts) on a per-chat basis
- **MOST MCPs/Integrations** - There are some limitations in cases where a "Knowledge" object is returned that I can't access, such as with web search

Limitations:
- **Web search results** - The full results are not exposed in the conversation history, so I can't track them properly
- **Research** - Most of it happens on the backend, so I can't track it
 
Token calculation is handled either through Anthropic's API (if you provide your key) or via [gpt-tokenizer](https://github.com/niieani/gpt-tokenizer).

## Privacy

The extension fetches your organization ID from claude.ai to synchronize usage data across devices using Firebase. For full details, see the [privacy policy](PRIVACY.md).

## UI

Most elements in the chat UI (Namely the length, cost, estimate, caching status) have a tooltip explaining them further.

![Claude Usage Tracker UI](https://github.com/lugia19/Claude-Usage-Extension/blob/main/ui_screenshot.png?raw=true)

## Building from source

Shared code lives in the [claude-ext-common](https://github.com/lugia19/claude-ext-common) submodule, so clone with `git clone --recurse-submodules` (or run `git submodule update --init` in an existing clone). Then run `build.bat`, which produces the Chrome, Firefox and Electron zips in `web-ext-artifacts/`.
